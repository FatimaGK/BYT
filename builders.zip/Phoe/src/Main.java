public class Main {

    public static void main(String[] args) {
        Phone.PhoneBuilder builder = new Phone.PhoneBuilder()
                .backView("Sandstone")
                .frontView("Amoled")
                .camera("15mp")
                .processor("A11");

            Phone phone=builder.build();
        System.out.println(phone);
    }
}