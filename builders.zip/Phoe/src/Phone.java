public class Phone {
    private String frontView;
    private String backView;
    private String processor;
    private String camera;

    public Phone(PhoneBuilder phoneBuilder) {
        this.frontView=phoneBuilder.frontView;
        this.backView=phoneBuilder.backView;
        this.processor=phoneBuilder.processor;
        this.camera=phoneBuilder.camera;
    }
    public Phone(String frontView, String backView, String processor, String camera) {
        this.frontView = frontView;
        this.backView = backView;
        this.processor = processor;
        this.camera = camera;
    }
    public String getFrontView() {
        return frontView;
    }

    public String getBackView() {
        return backView;
    }

    public String getProcessor() {
        return processor;
    }

    public String getCamera() {
        return camera;
    }


    @Override
    public String toString() {
        return "Phone: " + this.frontView + ", " + this.backView + ", " + this.processor + ", " + this.camera;
    }

    public static class PhoneBuilder {
        private String frontView;
        private String backView;
        private String processor;
        private String camera;

        public PhoneBuilder() {

        }
        public Phone build(){
            return new Phone(this);
        }

        public PhoneBuilder frontView(String frontView) {
            this.frontView = frontView;
            return this;
        }

        public PhoneBuilder backView(String backView) {
            this.backView = backView;
            return this;
        }

        public PhoneBuilder processor(String processor) {
            this.processor = processor;
            return this;
        }

        public PhoneBuilder camera(String camera) {
            this.camera = camera;
            return this;
        }
    }


}